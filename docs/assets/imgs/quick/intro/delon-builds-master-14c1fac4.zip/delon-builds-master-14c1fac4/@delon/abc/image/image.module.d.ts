export declare class ImageModule {
}
