export declare class SEErrorComponent {
}
