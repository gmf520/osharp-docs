export { FooterToolbarComponent } from './footer-toolbar.component';
export { FooterToolbarModule } from './footer-toolbar.module';
