export declare class DelonABCModule {
}
