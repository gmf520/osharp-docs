export { ErrorCollectComponent } from './error-collect.component';
export { ErrorCollectConfig } from './error-collect.config';
export { ErrorCollectModule } from './error-collect.module';
