import { ElementRef } from '@angular/core';
export declare class GlobalFooterItemComponent {
    host: ElementRef;
    href: string;
    blankTarget: boolean;
}
