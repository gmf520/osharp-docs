export declare class FullContentModule {
}
