/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
export function GlobalFooterLink() { }
if (false) {
    /** @type {?} */
    GlobalFooterLink.prototype.title;
    /** @type {?} */
    GlobalFooterLink.prototype.href;
    /** @type {?|undefined} */
    GlobalFooterLink.prototype.blankTarget;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2xvYmFsLWZvb3Rlci50eXBlcy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BkZWxvbi9hYmMvZ2xvYmFsLWZvb3Rlci8iLCJzb3VyY2VzIjpbImdsb2JhbC1mb290ZXIudHlwZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLHNDQUlDOzs7SUFIQyxpQ0FBYzs7SUFDZCxnQ0FBYTs7SUFDYix1Q0FBc0IiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgaW50ZXJmYWNlIEdsb2JhbEZvb3Rlckxpbmsge1xuICB0aXRsZTogc3RyaW5nO1xuICBocmVmOiBzdHJpbmc7XG4gIGJsYW5rVGFyZ2V0PzogYm9vbGVhbjtcbn1cbiJdfQ==