export { EllipsisComponent } from './ellipsis.component';
export { EllipsisModule } from './ellipsis.module';
