export declare class DatePickerModule {
}
