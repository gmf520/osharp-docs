/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
export {} from './zip.types';
export { ZipConfig } from './zip.config';
export { ZipService } from './zip.service';
export { ZipModule } from './zip.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BkZWxvbi9hYmMvemlwLyIsInNvdXJjZXMiOlsicHVibGljX2FwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsZUFBYyxhQUFhLENBQUM7QUFDNUIsMEJBQWMsY0FBYyxDQUFDO0FBQzdCLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLGNBQWMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCAqIGZyb20gJy4vemlwLnR5cGVzJztcbmV4cG9ydCAqIGZyb20gJy4vemlwLmNvbmZpZyc7XG5leHBvcnQgeyBaaXBTZXJ2aWNlIH0gZnJvbSAnLi96aXAuc2VydmljZSc7XG5leHBvcnQgeyBaaXBNb2R1bGUgfSBmcm9tICcuL3ppcC5tb2R1bGUnO1xuIl19