export declare class EllipsisModule {
}
