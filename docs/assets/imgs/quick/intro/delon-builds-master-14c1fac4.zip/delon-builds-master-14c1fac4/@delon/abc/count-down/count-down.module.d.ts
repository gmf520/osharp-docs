export declare class CountDownModule {
}
