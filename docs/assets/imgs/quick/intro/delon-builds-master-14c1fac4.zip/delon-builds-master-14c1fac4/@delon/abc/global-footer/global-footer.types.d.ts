export interface GlobalFooterLink {
    title: string;
    href: string;
    blankTarget?: boolean;
}
