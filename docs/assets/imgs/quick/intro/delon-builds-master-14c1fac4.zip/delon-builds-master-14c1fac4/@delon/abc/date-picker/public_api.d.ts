export { RangePickerComponent } from './range.component';
export * from './date-picker.config';
export { DatePickerModule } from './date-picker.module';
