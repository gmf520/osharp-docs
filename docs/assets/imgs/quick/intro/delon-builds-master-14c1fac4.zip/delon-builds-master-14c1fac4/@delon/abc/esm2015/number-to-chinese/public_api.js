/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
export {} from './number-to-chinese.interfaces';
export { numberToChinese } from './number-to-chinese';
export { NaNumberToChinesePipe } from './number-to-chinese.pipe';
export { NumberToChineseModule } from './number-to-chinese.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BkZWxvbi9hYmMvbnVtYmVyLXRvLWNoaW5lc2UvIiwic291cmNlcyI6WyJwdWJsaWNfYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxlQUFjLGdDQUFnQyxDQUFDO0FBQy9DLGdDQUFjLHFCQUFxQixDQUFDO0FBQ3BDLHNDQUFjLDBCQUEwQixDQUFDO0FBQ3pDLHNDQUFjLDRCQUE0QixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0ICogZnJvbSAnLi9udW1iZXItdG8tY2hpbmVzZS5pbnRlcmZhY2VzJztcbmV4cG9ydCAqIGZyb20gJy4vbnVtYmVyLXRvLWNoaW5lc2UnO1xuZXhwb3J0ICogZnJvbSAnLi9udW1iZXItdG8tY2hpbmVzZS5waXBlJztcbmV4cG9ydCAqIGZyb20gJy4vbnVtYmVyLXRvLWNoaW5lc2UubW9kdWxlJztcbiJdfQ==