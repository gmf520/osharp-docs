export declare class AvatarListItemComponent {
    src: string;
    text: string;
    icon: string;
    tips: string;
}
