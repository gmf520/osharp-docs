export declare class AvatarListModule {
}
