export * from './global-footer.types';
export * from './global-footer.component';
export * from './global-footer-item.component';
export * from './global-footer.module';
