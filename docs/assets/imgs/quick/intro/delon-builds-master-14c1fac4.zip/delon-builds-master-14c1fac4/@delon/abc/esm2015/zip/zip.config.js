/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class ZipConfig {
    constructor() {
        /**
         * Zip library path
         */
        this.url = '//cdn.bootcss.com/jszip/3.1.5/jszip.min.js';
        /**
         * Defines which zip optional utils should get loaded
         */
        this.utils = [];
    }
}
ZipConfig.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */ ZipConfig.ngInjectableDef = i0.defineInjectable({ factory: function ZipConfig_Factory() { return new ZipConfig(); }, token: ZipConfig, providedIn: "root" });
if (false) {
    /**
     * Zip library path
     * @type {?}
     */
    ZipConfig.prototype.url;
    /**
     * Defines which zip optional utils should get loaded
     * @type {?}
     */
    ZipConfig.prototype.utils;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiemlwLmNvbmZpZy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BkZWxvbi9hYmMvemlwLyIsInNvdXJjZXMiOlsiemlwLmNvbmZpZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFHM0MsTUFBTSxPQUFPLFNBQVM7SUFEdEI7Ozs7UUFLRSxRQUFHLEdBQVksNENBQTRDLENBQUM7Ozs7UUFJNUQsVUFBSyxHQUFjLEVBQUUsQ0FBQztLQUN2Qjs7O1lBVkEsVUFBVSxTQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRTs7Ozs7Ozs7SUFLaEMsd0JBQTREOzs7OztJQUk1RCwwQkFBc0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgWmlwQ29uZmlnIHtcbiAgLyoqXG4gICAqIFppcCBsaWJyYXJ5IHBhdGhcbiAgICovXG4gIHVybD86IHN0cmluZyA9ICcvL2Nkbi5ib290Y3NzLmNvbS9qc3ppcC8zLjEuNS9qc3ppcC5taW4uanMnO1xuICAvKipcbiAgICogRGVmaW5lcyB3aGljaCB6aXAgb3B0aW9uYWwgdXRpbHMgc2hvdWxkIGdldCBsb2FkZWRcbiAgICovXG4gIHV0aWxzPzogc3RyaW5nW10gPSBbXTtcbn1cbiJdfQ==