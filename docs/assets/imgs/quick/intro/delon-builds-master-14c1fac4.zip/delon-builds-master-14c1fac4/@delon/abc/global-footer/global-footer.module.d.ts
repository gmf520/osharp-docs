export declare class GlobalFooterModule {
}
