import { FullContentComponent } from './full-content.component';
export declare class FullContentToggleDirective {
    private parent;
    constructor(parent: FullContentComponent);
    _click(): void;
}
