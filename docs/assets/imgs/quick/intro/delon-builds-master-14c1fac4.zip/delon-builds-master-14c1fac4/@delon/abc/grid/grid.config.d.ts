export declare class SGConfig {
    /**
     * 间距，默认：`32`
     */
    gutter?: number;
    /**
     * 列数，默认：`2`
     */
    col?: number;
}
