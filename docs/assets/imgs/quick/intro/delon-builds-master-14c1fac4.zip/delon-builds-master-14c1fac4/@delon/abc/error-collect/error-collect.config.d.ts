export declare class ErrorCollectConfig {
    /**
     * 监听频率
     */
    freq?: number;
    /**
     * 顶部偏移值
     */
    offsetTop?: number;
}
