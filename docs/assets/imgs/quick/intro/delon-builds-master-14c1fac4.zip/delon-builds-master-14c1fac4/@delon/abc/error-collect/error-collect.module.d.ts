export declare class ErrorCollectModule {
}
