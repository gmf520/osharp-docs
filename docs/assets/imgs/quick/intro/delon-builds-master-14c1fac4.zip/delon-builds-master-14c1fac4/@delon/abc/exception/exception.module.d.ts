export declare class ExceptionModule {
}
