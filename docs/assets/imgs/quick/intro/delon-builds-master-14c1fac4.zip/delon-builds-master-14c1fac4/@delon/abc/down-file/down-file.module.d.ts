export declare class DownFileModule {
}
