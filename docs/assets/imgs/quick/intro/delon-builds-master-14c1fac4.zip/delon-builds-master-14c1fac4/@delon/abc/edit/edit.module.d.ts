export declare class SEModule {
}
