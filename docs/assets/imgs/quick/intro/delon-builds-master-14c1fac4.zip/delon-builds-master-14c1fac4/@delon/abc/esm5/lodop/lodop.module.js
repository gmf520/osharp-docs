/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { NgModule } from '@angular/core';
import { DelonUtilModule } from '@delon/util';
var LodopModule = /** @class */ (function () {
    function LodopModule() {
    }
    LodopModule.decorators = [
        { type: NgModule, args: [{
                    imports: [DelonUtilModule],
                },] }
    ];
    return LodopModule;
}());
export { LodopModule };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9kb3AubW9kdWxlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGRlbG9uL2FiYy9sb2RvcC8iLCJzb3VyY2VzIjpbImxvZG9wLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sYUFBYSxDQUFDO0FBRTlDO0lBQUE7SUFHMEIsQ0FBQzs7Z0JBSDFCLFFBQVEsU0FBQztvQkFDUixPQUFPLEVBQUUsQ0FBQyxlQUFlLENBQUM7aUJBQzNCOztJQUN5QixrQkFBQztDQUFBLEFBSDNCLElBRzJCO1NBQWQsV0FBVyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEZWxvblV0aWxNb2R1bGUgfSBmcm9tICdAZGVsb24vdXRpbCc7XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtEZWxvblV0aWxNb2R1bGVdLFxufSlcbmV4cG9ydCBjbGFzcyBMb2RvcE1vZHVsZSB7fVxuIl19