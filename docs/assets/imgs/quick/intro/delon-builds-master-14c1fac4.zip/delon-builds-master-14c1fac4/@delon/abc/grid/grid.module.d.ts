export declare class SGModule {
}
