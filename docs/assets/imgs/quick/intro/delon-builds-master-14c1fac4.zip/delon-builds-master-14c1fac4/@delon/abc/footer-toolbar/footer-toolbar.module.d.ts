export declare class FooterToolbarModule {
}
