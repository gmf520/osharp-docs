/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
export { SVContainerComponent } from './view-container.component';
export { SVTitleComponent } from './view-title.component';
export { SVComponent } from './view.component';
export { SVConfig } from './view.config';
export { SVModule } from './view.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BkZWxvbi9hYmMvdmlldy8iLCJzb3VyY2VzIjpbInB1YmxpY19hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLHFDQUFjLDRCQUE0QixDQUFDO0FBQzNDLGlDQUFjLHdCQUF3QixDQUFDO0FBQ3ZDLDRCQUFjLGtCQUFrQixDQUFDO0FBQ2pDLHlCQUFjLGVBQWUsQ0FBQztBQUM5Qix5QkFBYyxlQUFlLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgKiBmcm9tICcuL3ZpZXctY29udGFpbmVyLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL3ZpZXctdGl0bGUuY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vdmlldy5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi92aWV3LmNvbmZpZyc7XG5leHBvcnQgKiBmcm9tICcuL3ZpZXcubW9kdWxlJztcbiJdfQ==